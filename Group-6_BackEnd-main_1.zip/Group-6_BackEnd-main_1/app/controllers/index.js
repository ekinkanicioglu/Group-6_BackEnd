module.exports.homePage = function (req, res, next) {
    res.send('Welcome to SellNow');
}